package com.example.demo.controller;

import com.example.demo.service.AccountService;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;


@WebMvcTest(AccountController.class)
public class AccountControllerTest {
    //сообщения бизнесс валидаций
    public static final String COMPARE_TO_ZERO_VALIDATE = "Баланс не может быть отридцательным";
    public static final String MAX_BALANCE_VALIDATE = "Макс. баланс не может превышать 207% от первоначального(100)";

    //данные для заполнения
    public static final BigDecimal START_BALANCE = BigDecimal.valueOf(100);

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private AccountService accountService;

    @Test
    @Order(1)
    //ошибка value
    public void postValidateBadValue() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.put("/api/account/transfer")
                        .param("transfer_from", "1")
                        .param("transfer_to", "10")
                        .param("value", String.valueOf(BigDecimal.valueOf(250000000)))
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        //  .content(reqBody)
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().is4xxClientError());
    }

    @Test
    @Order(2)
    //ошибка account
    public void postValidateBadAccount() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.put("/api/account/transfer")
                        .param("transfer_from", "1")
                        .param("transfer_to", "999999999999999999999999999999999999")
                        .param("value", String.valueOf(BigDecimal.valueOf(10)))
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        //  .content(reqBody)
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().is4xxClientError());
    }

    @Test
    @Order(3)
    //статус 200
    public void postValidateSuccess() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.put("/api/account/transfer")
                        .param("transfer_from", "1")
                        .param("transfer_to", "1")
                        .param("value", String.valueOf(BigDecimal.valueOf(0)))
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        //  .content(reqBody)
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk()).andReturn();
        //   .andExpect(jsonPath("$.details[*].errorMessage", containsInAnyOrder(COMPARE_TO_ZERO_VALIDATE)))
        ;
    }
}