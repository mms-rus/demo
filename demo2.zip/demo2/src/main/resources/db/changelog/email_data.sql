CREATE TABLE IF NOT EXISTS public.email_data
(
    id bigint NOT NULL,
    email character varying(500),
    user_id bigint not null,
    CONSTRAINT PK_email_data PRIMARY KEY (id)
);
ALTER TABLE public.email_data ADD CONSTRAINT email_data_user_fk FOREIGN KEY (user_id) REFERENCES public."user"(id);
