CREATE TABLE IF NOT EXISTS public.account
(
    id bigint NOT NULL,
    balance numeric(18,2),
    user_id bigint not null,
    CONSTRAINT PK_account PRIMARY KEY (id)
    );
ALTER TABLE public.account ADD CONSTRAINT account_user_fk FOREIGN KEY (user_id) REFERENCES public."user"(id);
