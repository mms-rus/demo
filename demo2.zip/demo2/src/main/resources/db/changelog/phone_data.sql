CREATE TABLE IF NOT EXISTS public.phone_data
(
    id bigint NOT NULL,
    phone character varying(13),
    user_id bigint not null,
    CONSTRAINT PK_phone_data PRIMARY KEY (id)
);
ALTER TABLE public.phone_data ADD CONSTRAINT phone_user_fk FOREIGN KEY (user_id) REFERENCES public."user"(id);
