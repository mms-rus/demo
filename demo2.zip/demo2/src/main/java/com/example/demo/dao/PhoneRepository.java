package com.example.demo.dao;

import com.example.demo.model.PhoneData;
import liquibase.integration.ant.type.DatabaseType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;

public interface PhoneRepository extends JpaRepository<PhoneData, BigInteger> {
    PhoneData findPhoneDataByPhone(String phone);
}
