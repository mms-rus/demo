package com.example.demo.service;

import com.example.demo.model.User;
import com.example.demo.model.common.*;
import io.jsonwebtoken.Claims;
import jakarta.security.auth.message.AuthException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;

import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.*;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserService userService;
    private final Map<String, String> refreshStorage = new HashMap<>();
    private final JwtProvider jwtProvider;

    public String getCurrentUser() {
        // Получение имени пользователя из контекста Spring Security
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpSession session = attr.getRequest().getSession(true); // true == allow create
        SecurityContextImpl sci = (SecurityContextImpl) session.getAttribute("SPRING_SECURITY_CONTEXT");
        if (Objects.nonNull(sci)) {
            var authentication = sci.getAuthentication();
            String user = authentication.getName();
            return user;

        } else {
            return null;
        }

    }


    public JwtResponse login(String login, String password) throws AuthException {
        User user = userService.getUserByEmail(login);
        if (Objects.isNull(user)) {
            user = userService.getUserByPhone(login);
        }
        if (user.getPassword().equals(password)) {
            final String accessToken = jwtProvider.generateAccessToken(user);
            final String refreshToken = jwtProvider.generateRefreshToken(user);
            final Claims claims = jwtProvider.getRefreshClaims(refreshToken);
            final JwtAuthentication jwtInfoToken = JwtUtils.generate(claims);
            jwtInfoToken.setAuthenticated(true);
            jwtInfoToken.setUsername(user.getUsername());
            jwtInfoToken.setFirstName(user.getUsername());
            Set<Role> roleSet = new HashSet<>();
            roleSet.add(Role.ADMIN);
            roleSet.add(Role.USER);
            jwtInfoToken.setRoles(roleSet);
            saveSecurityContext(SecurityContextHolder.getContext(), jwtInfoToken);
            refreshStorage.put(user.getUsername(), refreshToken);
            return new JwtResponse(accessToken, refreshToken);
        } else {
            throw new AuthException("Неправильный пароль");
        }
    }

    private void saveSecurityContext(SecurityContext context, JwtAuthentication jwtInfoToken) {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        securityContext.setAuthentication(jwtInfoToken);
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = null;
        if (requestAttributes instanceof ServletRequestAttributes) {
            request = ((ServletRequestAttributes) requestAttributes).getRequest();

        }
        HttpSession session = request.getSession(true);
        session.setAttribute("SPRING_SECURITY_CONTEXT", securityContext);
    }

}
