package com.example.demo.service;

import com.example.demo.dto.UserDto;
import com.example.demo.dto.UserFilterDto;
import com.example.demo.model.Account;
import com.example.demo.model.User;

import java.util.Date;
import java.util.List;

public interface UserService {
    List<Account> findAccountList(Integer offset, Integer size);

    List<User> getUserListByFilter(String name, String email, String phone, Date dtOfBirth, Integer offset, Integer size);

}
