package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.math.BigInteger;

@Data
@Entity
@Table(name = "\"account\"")
public class Account {
    @Id
    @Column(name = "\"id\"")
    private BigInteger id;

    @Column(name = "\"balance\"")
    private BigDecimal balance;

    @ManyToOne
    @JoinColumn(name = "\"user_id\"", foreignKey = @ForeignKey(name = "account_user_fk"), insertable = false, updatable = false)
    private User user;

    @Column(name = "\"user_id\"", nullable = false)
    private BigInteger userId;
}
