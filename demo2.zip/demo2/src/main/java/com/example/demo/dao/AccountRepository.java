package com.example.demo.dao;

import com.example.demo.model.Account;
import com.example.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;

public interface AccountRepository extends JpaRepository<Account, BigInteger> {
    Account findByUserId(BigInteger userId);

    Account findByUser(User byUsername);
}
