package com.example.demo.controller;

import com.example.demo.dto.UserDto;
import com.example.demo.model.Account;
import com.example.demo.model.User;
import com.example.demo.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserController {
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    UserService userService;

   /* @Operation(summary = "Список всех пользователей")
    @GetMapping("/all")
    public List<UserDto> getUsersAll() {
        logger.info("Запрос на просмотр пользователей");
        return userService.findAll();
    }*/

    @Operation(summary = "Поиск пользователей с фильтрами и пагинацией")
    @GetMapping()
    public List<User> getUserListByFilter(@Valid @RequestParam(name = "имя пользователя", required = false) String name,
                                          @Valid @RequestParam(name = "email пользователя", required = false) String email,
                                          @Valid @RequestParam(name = "телефон пользователя", required = false) String phone,
                                          //   @Valid @RequestParam(name = "дата рождения", defaultValue = "01.01.2000") String dtOfBirth,
                                          @Valid @RequestParam(value = "date", required = false)
                                              @DateTimeFormat(pattern = "yyyy-MM-dd") Date dtOfBirth,
                                          @Valid @RequestParam(name = "смещение(offset)", defaultValue = "0") Integer offset,
                                          @Valid @RequestParam(name = "размер(size)", defaultValue = "100") Integer size) {
        logger.info("Поиск пользователей с фильтрами и пагинацией");
        return userService.getUserListByFilter(name, email, phone, dtOfBirth, offset, size);
    }

    @GetMapping("/account")
    @Operation(summary = "Список всех account")
    public List<Account> getUAccountList(@RequestParam(name = "смещение", defaultValue = "0") Integer offset,
                                         @RequestParam(name = "размер", defaultValue = "100") Integer size) {
        logger.info("Запрос account");
        return userService.findAccountList(offset, size);
    }

}
