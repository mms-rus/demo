package com.example.demo.dto.wrapped;

import org.springframework.web.ErrorResponse;

import java.io.Serializable;

public class ExeptionWrappedOne extends WrapperOne<ErrorResponse> implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 434058557146012758L;

    public ExeptionWrappedOne() {
        this.setSuccess(false);
        this.setMessage("Alert_GetOrCreateCardCacheAsync_error");
        this.setSnackbarType("error");
        this.setContent(null);
    }
}