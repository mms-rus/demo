package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigInteger;

@Data
@Entity
@Table(name = "\"phone_data\"")
public class PhoneData {
    @Id
    @Column(name = "\"id\"")
    private BigInteger id;

    @Column(name = "\"phone\"", length = 13)
    private String phone;

    @ManyToOne
    @JoinColumn(name = "\"user_id\"", foreignKey = @ForeignKey(name = "phone_user_fk"), insertable = false, updatable = false)
    private User user;

    @Column(name = "\"user_id\"", nullable = false)
    private BigInteger userId;
}
