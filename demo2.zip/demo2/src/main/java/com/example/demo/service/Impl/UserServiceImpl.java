package com.example.demo.service.Impl;

import com.example.demo.dao.AccountRepository;
import com.example.demo.dao.UserRepository;
import com.example.demo.dao.common.OffsetBasedPageRequest;
import com.example.demo.dto.*;
import com.example.demo.model.Account;
import com.example.demo.model.User;
import com.example.demo.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Pageable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service("UserService")
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    @Autowired
    UserRepository userRepository;
    @Autowired
    AccountRepository accountRepository;


    @Override
    public List<Account> findAccountList(Integer offset, Integer size) {
        Pageable pageable = new OffsetBasedPageRequest(offset, size);

        List<Account> accountList = accountRepository.findAll(pageable).getContent();
        return accountList.stream().limit(2000).collect(Collectors.toList());
    }

    @Override
    public List<User> getUserListByFilter(String name, String email, String phone, Date dtOfBirth, Integer offset, Integer size) {
        Pageable pageable = new OffsetBasedPageRequest(offset, size);
        List<User> resultList = new ArrayList<>();
        resultList = userRepository.findUserListByFilter(name, email, phone, dtOfBirth);
    /*    final int start = (int)pageable.getOffset();
        final int end = Math.min((start + pageable.getPageSize()), resultList.size());*/
        Page<User> page = new PageImpl<>(resultList, pageable, resultList.size());
        return page.getContent();
    }

  /*  @Override
    public ResponsePage<UserDto> findUserListBuFilter(String filter, QueryPage queryPage) {
        return userRepository.findAll();
    }*/
}
