package com.example.demo.dao;

import com.example.demo.model.EmailData;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;

public interface EmailRepository extends JpaRepository<EmailData, BigInteger> {
}
