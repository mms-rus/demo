package com.example.demo.controller;

import com.example.demo.service.AccountService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/account")
public class AccountController {

    @Autowired
    AccountService accountService;

    @Operation(summary = "Увеличение баланса на 10%")
    @PutMapping("/balance")
    public void updateBalanceAllUser() {
        accountService.updateBalanceAllUser();
    }

    @Operation(summary = "Трансфер денежных средств между пользователями")
    @PutMapping("/transfer")
    public void updateTransferMoney(@Valid @RequestParam(name = "пользователь отправляющий данные", required = false) BigInteger transfer_from,
                                    @Valid @RequestParam(name = "пользователь принимающий данные", required = false) BigInteger transfer_to,
                                    @Valid @RequestParam(name = "сумма", required = false) BigDecimal value) {
        accountService.updateTransferMoney(transfer_from, transfer_to, value);
    }
}
