package com.example.demo.model.common;

import lombok.Getter;
import org.springframework.security.core.userdetails.User;

@Getter
public class SecurityUser extends User {
    private final Long id;

    public SecurityUser(com.example.demo.model.User user) {
        super(user.getName(),
                user.getPassword(),
                null);
        this.id = user.getId().longValue();
    }

}
