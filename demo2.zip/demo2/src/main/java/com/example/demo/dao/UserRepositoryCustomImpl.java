package com.example.demo.dao;

import com.example.demo.dto.UserFilterDto;
import com.example.demo.model.User;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class UserRepositoryCustomImpl implements UserRepositoryCustom {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<User> findUserListByFilter(Integer offset, Integer size, UserFilterDto filter) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<User> query = builder.createQuery(User.class);
        buildQueryByParam(query, builder, filter, offset, size);
        return entityManager.createQuery(query).getResultList();
    }

    @SuppressWarnings({"rawtypes", "uncheked"})
    private void buildQueryByParam(CriteriaQuery<User> query,
                                   CriteriaBuilder builder,
                                   UserFilterDto filter,
                                   Integer offset,
                                   Integer size) {
        Root<User> userRoot=query.from(User.class);
        query.select(userRoot);

    }
}
