package com.example.demo.dao;

import com.example.demo.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

public interface UserRepository extends JpaRepository<User, BigInteger> {
    @Query(value = """
            select u from User u 
                     join EmailData e on e.user=u
                     join PhoneData p on p.user=u
                     where u.name =:name or e.email=:email or p.phone=:phone
            """)
    List<User> findUserListByFilter(
            String name,
            String email, String phone, Date dtOfBirth);

    @Query(value = """
            select u.* from public.user u 
                     join email_data e on e.user_id=u.id
                     join phone_data p on p.user_id=u.id
                     where (u.name LIKE '%' || :name ||'%' or :name is null)
                     and (e.email=:email or :email is null)
                     and (p.phone=:phone or :phone is null)
                     and (u.date_of_birth >=:date or :date is null)
            """, nativeQuery = true)
    List<User> findUserListByFilter(String name, String email, String phone, String dtOfBirth);

    User findByName(String username);
}
