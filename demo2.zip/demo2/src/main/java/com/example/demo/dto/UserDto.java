package com.example.demo.dto;

import com.example.demo.model.User;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.Date;

@Data
@Schema(description = "")
public class UserDto {
    @Schema(description = "")
    private BigInteger id;
    private String name;
    private Date dtBirth;
    private String password;


}
