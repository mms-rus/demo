package com.example.demo.service.Impl;

import com.example.demo.dao.AccountRepository;
import com.example.demo.model.Account;
import com.example.demo.service.AccountService;
import com.example.demo.service.common.BusinessValidationException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

@Service("AccountService")
@RequiredArgsConstructor
public class AccountServiceImpl implements AccountService {
    private final static BigDecimal startBalance = BigDecimal.valueOf(100);
    private final static BigDecimal maxBalance = BigDecimal.valueOf(207);
    private static final Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);

    @Autowired
    AccountRepository accountRepository;

    @Override
    public void updateBalanceAllUser() {
        List<Account> accountList = accountRepository.findAll();
        for (Account a : accountList) {
            if (validBalance(a)) {
                a.setBalance(a.getBalance().multiply(BigDecimal.valueOf(1.1)));
                accountRepository.save(a);
                logger.info("Баланс пользователя=" + a.getUserId() + " увеличен на 10% ");
            }
        }
    }

    @Override
    @Transactional
    public void updateTransferMoney(BigInteger transfer_from, BigInteger transfer_to, BigDecimal value) {
        Account account_from = accountRepository.findByUserId(transfer_from);
        Account account_to = accountRepository.findByUserId(transfer_to);
        if (compareToZeroBalance(account_from, value)) {
            account_from.setBalance(account_from.getBalance().subtract(value));
            account_to.setBalance(account_to.getBalance().add(value));
            accountRepository.save(account_from);
            accountRepository.save(account_to);
            logger.info("Списание баланса c пользователя=" + account_from.getUserId() + " на сумму " + value
                    + " на счет пользователя=" + account_to.getUserId());
        } else {
            logger.info("Ошибка списания баланса c пользователя=" + account_from.getUserId() + " на сумму " + value
                    + " на счет пользователя=" + account_to.getUserId() + "Баланс пользователя не может быть отридцательным!");
            throw new RuntimeException("Баланс на может быть отридцательным");
        }
    }

    private boolean compareToZeroBalance(Account account_from, BigDecimal value) {
        return account_from.getBalance().subtract(value).compareTo(BigDecimal.valueOf(0)) >= 0;
    }

    private boolean validBalance(Account a) {
        return maxBalance.compareTo(a.getBalance().multiply(BigDecimal.valueOf(1.1))) > 0;
    }
}
