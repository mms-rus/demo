package com.example.demo.service.Impl;

import com.example.demo.dao.AccountRepository;
import com.example.demo.dto.wrapped.DtoWrapper;
import com.example.demo.model.Account;
import com.example.demo.service.AccountService;
import com.example.demo.service.common.BusinessValidationException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.Synchronized;
import org.hibernate.annotations.Synchronize;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Objects;

@Service("AccountService")
@RequiredArgsConstructor
public class AccountServiceImpl implements AccountService {
    private final static BigDecimal startBalance = BigDecimal.valueOf(100);
    private final static BigDecimal maxBalance = BigDecimal.valueOf(207);
    private static final Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);

    @Autowired
    AccountRepository accountRepository;

    @Override
    @Transactional
    public void updateBalanceAllUser() {
        List<Account> accountList = accountRepository.findAll();
        for (Account a : accountList) {
            if (validBalance(a)) {
                a.setBalance(a.getBalance().multiply(BigDecimal.valueOf(1.1)));
                accountRepository.save(a);
                logger.info("Баланс пользователя=" + a.getUserId() + " увеличен на 10% ");
            }
        }
    }

    @Override
    @Transactional
    public DtoWrapper updateTransferMoney(BigInteger transfer_from, BigInteger transfer_to, BigDecimal value) {
        Account account_from = accountRepository.findByUserId(transfer_from);
        Account account_to = accountRepository.findByUserId(transfer_to);
        if (Objects.isNull(account_to)) {
            logger.info("Передан не существующий user=" + transfer_to);
            return null;
        } else if (compareToZeroBalance(account_from, value)) {
            updateBalanceTwoUser(account_from, account_to, value);
            logger.info("Списание баланса c пользователя=" + account_from.getUserId() + " на сумму " + value
                    + " на счет пользователя=" + account_to.getUserId());
            return DtoWrapper.builder().message("success").success(true).build();
        } else {
            logger.info("Ошибка списания баланса c пользователя=" + account_from.getUserId() + " на сумму " + value
                    + " на счет пользователя=" + account_to.getUserId() + "Баланс пользователя не может быть отридцательным!");

            return null;
        }

    }


    private void updateBalanceTwoUser(Account account_from, Account account_to, BigDecimal value) {
        if (Objects.nonNull(account_from)) {
            synchronized (account_from) {
                synchronized (account_to) {
                    account_from.setBalance(account_from.getBalance().subtract(value));
                    account_to.setBalance(account_to.getBalance().add(value));
                    //списание
                    accountRepository.save(account_from);
                    //зачисление
                    accountRepository.save(account_to);
                }
            }
        }
    }

    private boolean compareToZeroBalance(Account account_from, BigDecimal value) {
        return account_from.getBalance().subtract(value).compareTo(BigDecimal.valueOf(0)) >= 0;
    }

    private boolean validBalance(Account a) {
        return maxBalance.compareTo(a.getBalance().multiply(BigDecimal.valueOf(1.1))) > 0;
    }
}
