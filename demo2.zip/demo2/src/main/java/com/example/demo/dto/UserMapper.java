package com.example.demo.dto;

import com.example.demo.model.User;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.stereotype.Component;

import java.math.BigInteger;
import java.util.List;
import java.util.stream.Collectors;


@Component
@Mapper(componentModel="spring")
public interface UserMapper {
   /* public UserDto mapDtoToEntity(User user) {

          return UserDto.builder().id(user.getId()).build();
    }
    public List<UserDto> toDtoList(List<User> dtoList) {
        return dtoList.stream()
                .map(this::mapDtoToEntity)
                .collect(Collectors.toList());
    }*/
   /* @Mapping(target = "id", source = "0")
    @Mapping(target = "name", source = "user.name")*/
    UserDto toDto(User user);
    List<UserDto> toDto(List<User> dtoList);


}
