package com.example.demo.service;

import com.example.demo.dto.wrapped.DtoWrapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;

@Service
public interface AccountService {
    void updateBalanceAllUser();

    DtoWrapper updateTransferMoney(BigInteger transfer_from, BigInteger transfer_to, BigDecimal value);

    DtoWrapper updateTransferMoneyAuth(BigInteger transfer_to, BigDecimal value);
}
