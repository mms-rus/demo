package com.example.demo.service;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;

@Service
public interface AccountService {
    void updateBalanceAllUser();

    void updateTransferMoney(BigInteger transfer_from, BigInteger transfer_to, BigDecimal value);
}
