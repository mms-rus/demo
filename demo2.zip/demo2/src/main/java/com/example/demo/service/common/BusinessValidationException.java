package com.example.demo.service.common;

import com.example.demo.model.common.ErrorModel;

import java.util.Collections;
import java.util.List;

public class BusinessValidationException extends RuntimeException{
    private final List<ErrorModel> errors;

    public BusinessValidationException(String field, String message){
        super(message);
        errors= Collections.singletonList(new ErrorModel(field, message));
    }

    public BusinessValidationException(String message){
        this(null, message);
    }
    public BusinessValidationException(List<ErrorModel> errors){
        super();
        this.errors=errors;
    }

    public List<ErrorModel> getErrors(){
        return errors;
    }
}
