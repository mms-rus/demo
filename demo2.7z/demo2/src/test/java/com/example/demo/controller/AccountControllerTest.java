package com.example.demo.controller;

import com.example.demo.service.AccountService;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.math.BigInteger;

@WebMvcTest(AccountController.class)
public class AccountControllerTest {
    //сообщения бизнесс валидаций
    public static final String COMPARE_TO_ZERO_VALIDATE = "Баланс не может быть отридцательным";
    //данные для заполнения
    public static final BigDecimal START_BALANCE = BigDecimal.valueOf(100);

    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    AccountService accountService;


    @Test
    @Order(1)
    //ошибка value
    public void postValidateBadValue() throws Exception {

        mockMvc.perform(MockMvcRequestBuilders.put("/api/account/transfer")
                        .param("transfer_from", String.valueOf(BigInteger.valueOf(1)))
                        .param("transfer_to", String.valueOf(BigInteger.valueOf(2)))
                        .param("value", String.valueOf(BigDecimal.valueOf(250000000)))
                // .accept(MediaType.APPLICATION_JSON)
        ).andExpect(status().is5xxServerError());
    }

    @Test
    @Order(2)
    //ошибка account
    public void postValidateBadAccount() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.put("/api/account/transfer")
                        .param("transfer_from", "1")
                        .param("transfer_to", "99999999999999999999")
                        .param("value", String.valueOf(BigDecimal.valueOf(0))))
                .andExpect(status().is5xxServerError());
    }


}