CREATE TABLE IF NOT EXISTS public.user
(
    id bigint NOT NULL,
    name character varying(500),
    date_of_birth date,
    password character varying(500),
    CONSTRAINT PK_user PRIMARY KEY (id)
);