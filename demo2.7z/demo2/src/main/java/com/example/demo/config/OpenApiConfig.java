package com.example.demo.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;

@OpenAPIDefinition(
        info = @Info(
                title = "Loyalty System Api",
                description = "Loyalty System", version = "1.0.0",
                contact = @Contact(
                        name = "mms",
                        email = "63_marie@mail.ru",
                        url = "http://localhost:8080/swagger-ui/index.html"
                )
        )
)
public class OpenApiConfig {
}
