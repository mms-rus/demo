package com.example.demo.model.common;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.data.domain.Sort;

@Data
@Schema(description = "Запрос для пагинации")
public class QueryPage {
    @Schema(description = "Размер страницы")
    private int size;

    @Schema(description = "Смещение")
    private int offset;

    @Schema(description = "Направление сортировки", implementation = Sort.Direction.class)
    private Sort.Direction sortDirection = Sort.Direction.ASC;

    @Schema(description = "Поле сортировки")
    private String sortBy = "id";

    public static QueryPage getWithoutSort() {
        QueryPage page = new QueryPage();
       /* page.setSortBy(null);
        page.setSortDirection(null);*/
        return page;
    }
}
