package com.example.demo.service.Impl;

import com.example.demo.dao.AccountRepository;
import com.example.demo.dao.EmailRepository;
import com.example.demo.dao.PhoneRepository;
import com.example.demo.dao.UserRepository;
import com.example.demo.dao.common.OffsetBasedPageRequest;
import com.example.demo.dto.*;
import com.example.demo.model.Account;
import com.example.demo.model.User;
import com.example.demo.service.UserService;
import com.example.demo.service.common.BusinessValidationException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Pageable;

import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

@Service("UserService")
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    @Autowired
    UserRepository userRepository;
    @Autowired
    AccountRepository accountRepository;
    @Autowired
    EmailRepository emailRepository;
    @Autowired
    PhoneRepository phoneRepository;


    @Override
    @Cacheable(value = "accountCache")
    public List<Account> findAccountList(Integer offset, Integer size) {
        Pageable pageable = new OffsetBasedPageRequest(offset, size);
        List<Account> accountList = accountRepository.findAll(pageable).getContent();
        return accountList.stream().limit(2000).collect(Collectors.toList());
    }

    @Override
    @Cacheable(value = "userCache", key = "#email")
    public User getUserByEmail(String email) {
        return emailRepository.findEmailDataByEmail(email).getUser();
    }

    @Override
    public List<User> getUserListByFilter(String name, String email, String phone, Date dtOfBirth, Integer offset, Integer size) {
        Pageable pageable = new OffsetBasedPageRequest(offset, size);
        List<User> resultList = new ArrayList<>();
        resultList = userRepository.findUserListByFilter(name, email, phone, Objects.nonNull(dtOfBirth) ? dtOfBirth.toString() : null);
    /*    final int start = (int)pageable.getOffset();
        final int end = Math.min((start + pageable.getPageSize()), resultList.size());*/
        Page<User> page = new PageImpl<>(resultList, pageable, resultList.size());
        return page.getContent();
    }

    @Override
    @Cacheable(value = "userCache", key = "#phone")
    public User getUserByPhone(String phone) {
        return phoneRepository.findPhoneDataByPhone(phone).getUser();

    }

    @Override
    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Cacheable(value = "userCache", key = "#userId")
    public User getUserById(BigInteger userId) {
        // Симулируем вызов базы данных
        return userRepository.findById(userId)
                .orElseThrow(() -> new BusinessValidationException("Пользователя с id=" + userId.toString() + "не существует"));
    }

}
