package com.example.demo;

import com.example.demo.service.AccountService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.util.Random;

@SpringBootApplication
public class Demo2Application {
    private static final Logger logger = LoggerFactory.getLogger(Demo2Application.class);
    @Autowired AccountService accountService;

    static class MyThred extends Thread {


        private String message;
        private final AccountService service;

        public MyThred(AccountService service, String message) {
            this.message = message;
            this.service = service;
        }

        @Override
        public void run() {
            while (true) {
                System.out.println(message);
                service.updateBalanceAllUser();
                try {
                    Thread.sleep(new Random().nextInt(60000));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        ApplicationContext applicationContext =SpringApplication.run(Demo2Application.class, args);
        AccountService service = applicationContext.getBean(AccountService.class);
        Thread thread = new MyThred(service, "Увеличение баланса 100");
        thread.start();
    }

}
