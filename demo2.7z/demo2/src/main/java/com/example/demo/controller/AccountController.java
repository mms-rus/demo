package com.example.demo.controller;

import com.example.demo.dto.wrapped.DtoWrapper;
import com.example.demo.dto.wrapped.ExeptionWrappedOne;
import com.example.demo.service.AccountService;
import com.example.demo.service.common.ErrorResponse;
import com.example.demo.service.common.NotFoundException;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.math.BigDecimal;
import java.math.BigInteger;

@RestController
@RequestMapping("/api/account")
public class AccountController {
    private static final Logger logger = LoggerFactory.getLogger(AccountController.class);

    @Autowired
    AccountService accountService;

    @ExceptionHandler
    private ResponseEntity<ExeptionWrappedOne> handleException(NotFoundException e) {
        ErrorResponse response = new ErrorResponse("");
        logger.error(e.getMessage(), (Object) e.getStackTrace());
        ExeptionWrappedOne absExeptionWrappedOne = new ExeptionWrappedOne();
      //  absExeptionWrappedOne.setContent(response);
        return new ResponseEntity<>(absExeptionWrappedOne, HttpStatus.NOT_FOUND);
    }


    @Operation(summary = "Трансфер денежных средств между пользователями(без авторизации)")
    @PutMapping("/transfer")
    public ResponseEntity<?> updateTransferMoney(@RequestParam BigInteger transfer_from,
                                                 @RequestParam BigInteger transfer_to,
                                                 @RequestParam BigDecimal value) {

        DtoWrapper result = accountService.updateTransferMoney(transfer_from, transfer_to, value);
        if (result == null) {
            NotFoundException notFoundException = new NotFoundException();
            logger.error(new NullPointerException().getMessage());
            return new ResponseEntity<>(result, HttpStatus.INTERNAL_SERVER_ERROR);//handleException(notFoundException);
        }
        return result.isSuccess() ? new ResponseEntity<>(result, HttpStatus.OK) : new ResponseEntity<>(result, HttpStatus.NOT_FOUND);
    }
    @Operation(summary = "Трансфер денежных средств между пользователями(с авторизацией)")
    @PutMapping("/transferAuth")
    public ResponseEntity<?> updateTransferMoneyAuth(@RequestParam BigInteger transfer_to,
                                                     @RequestParam BigDecimal value) {

        DtoWrapper result = accountService.updateTransferMoneyAuth(transfer_to, value);
        if (result == null) {
            NotFoundException notFoundException = new NotFoundException();
            logger.error(new NullPointerException().getMessage());
            return new ResponseEntity<>(result, HttpStatus.INTERNAL_SERVER_ERROR);//handleException(notFoundException);
        }
        return result.isSuccess() ? new ResponseEntity<>(result, HttpStatus.OK) : new ResponseEntity<>(result, HttpStatus.NOT_FOUND);
    }
}
