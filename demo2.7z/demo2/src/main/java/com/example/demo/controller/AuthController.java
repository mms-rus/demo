package com.example.demo.controller;


import com.example.demo.model.User;
import com.example.demo.model.common.JwtRequest;
import com.example.demo.model.common.JwtResponse;
import com.example.demo.model.common.RefreshJwtRequest;
import com.example.demo.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.security.auth.message.AuthException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/auth")
@RequiredArgsConstructor
public class AuthController {
    private final AuthService authService;

    @PostMapping("login")
    @Operation(summary = "Авторизация")
    public ResponseEntity<JwtResponse> login(@RequestParam String login, String password) throws AuthException {
        final JwtResponse token = authService.login(login, password);
        return ResponseEntity.ok(token);
    }

}
