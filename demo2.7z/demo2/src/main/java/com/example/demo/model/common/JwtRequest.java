package com.example.demo.model.common;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Data
public class JwtRequest {
    private String email;
    private String password;
}
