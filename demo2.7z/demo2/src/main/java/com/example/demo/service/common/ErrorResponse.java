package com.example.demo.service.common;

public class ErrorResponse {
    private String massage;
    //private long timestamp;

    public ErrorResponse(String massage/*, long timestamp*/) {
        this.massage = massage;
        //this.timestamp = timestamp;
    }

    public String getMassage() {
        return massage;
    }

    public void setMassage(String massage) {
        this.massage = massage;
    }

}
