package com.example.demo.service.Impl;

import com.example.demo.dao.AccountRepository;
import com.example.demo.dao.UserRepository;
import com.example.demo.dto.wrapped.DtoWrapper;
import com.example.demo.model.Account;
import com.example.demo.service.AccountService;
import com.example.demo.service.AuthService;
import com.example.demo.service.common.BusinessValidationException;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Objects;

@Service("AccountService")
public class AccountServiceImpl implements AccountService {
    private final static BigDecimal startBalance = BigDecimal.valueOf(100);
    private final static BigDecimal maxBalance = BigDecimal.valueOf(207);
    private static final Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);

    private final AccountRepository accountRepository;
    private final AuthService authService;
    private final UserRepository userRepository;

    public AccountServiceImpl(AccountRepository accountRepository,
                              AuthService authService,
                              UserRepository userRepository) {
        this.accountRepository = accountRepository;
        this.authService = authService;
        this.userRepository = userRepository;
    }


    @Override
    @Transactional
    public void updateBalanceAllUser() {
        List<Account> accountList = accountRepository.findAll();
        for (Account a : accountList) {
            if (validBalance(a)) {
                a.setBalance(a.getBalance().multiply(BigDecimal.valueOf(1.1)));
                accountRepository.save(a);
                logger.info("Баланс пользователя=" + a.getUserId() + " увеличен на 10% ");
            }
        }
    }

    @Override
    @Transactional
    public DtoWrapper updateTransferMoney(BigInteger transfer_from, BigInteger transfer_to, BigDecimal value) {
        Account account_from = accountRepository.findByUserId(transfer_from);
        Account account_to = accountRepository.findByUserId(transfer_to);
        if (Objects.isNull(account_to)) {
            logger.info("Передан не существующий user=" + transfer_to);
            throw new BusinessValidationException("");

        } else if (updateBalanceTwoUser(account_from, account_to, value)) {
            logger.info("Списание баланса c пользователя=" + account_from.getUserId() + " на сумму " + value
                    + " на счет пользователя=" + account_to.getUserId());
            return DtoWrapper.builder().message("success").success(true).build();
        } else {
            logger.info("Ошибка списания баланса c пользователя=" + account_from.getUserId() + " на сумму " + value
                    + " на счет пользователя=" + account_to.getUserId() + "Баланс пользователя не может быть отридцательным!");

            return DtoWrapper.builder().message("error").success(false).build();
        }

    }

    @Override
    public DtoWrapper updateTransferMoneyAuth(BigInteger transfer_to, BigDecimal value) {
        String userName = authService.getCurrentUser();
        if (Objects.isNull(userName)) {
            logger.info("Ошибка списания баланса. Необходима авторизация");
            throw new BusinessValidationException("Пользователь неопределен. Необходима авторизация!");
        }
        Account account_to = accountRepository.findByUserId(transfer_to);
        Account account_from = accountRepository.findByUser(userRepository.findByUsername(userName));
        if (Objects.isNull(account_to)) {
            logger.info("Передан не существующий user=" + transfer_to);
            throw new BusinessValidationException("");

        } else if (updateBalanceTwoUser(account_from, account_to, value)) {
            logger.info("Списание баланса c пользователя=" + account_from.getUserId() + " на сумму " + value
                    + " на счет пользователя=" + account_to.getUserId());
            return DtoWrapper.builder().message("success").success(true).build();
        } else {
            logger.info("Ошибка списания баланса c пользователя=" + account_from.getUserId() + " на сумму " + value
                    + " на счет пользователя=" + account_to.getUserId() + "Баланс пользователя не может быть отридцательным!");

            return DtoWrapper.builder().message("error").success(false).build();
        }
    }


    public Boolean updateBalanceTwoUser(Account account_from, Account account_to, BigDecimal value) {
        if (compareToZeroBalance(account_from, value)) {
            synchronized (account_from) {
                synchronized (account_to) {
                    account_from.setBalance(account_from.getBalance().subtract(value));
                    account_to.setBalance(account_to.getBalance().add(value));
                    //списание
                    accountRepository.save(account_from);
                    //зачисление
                    accountRepository.save(account_to);
                }
            }
            return true;
        } else {
            return false;
        }
    }

    private boolean compareToZeroBalance(Account account_from, BigDecimal value) {
        return account_from.getBalance().subtract(value).compareTo(BigDecimal.valueOf(0)) >= 0;
    }

    private boolean validBalance(Account a) {
        return maxBalance.compareTo(a.getBalance().multiply(BigDecimal.valueOf(1.1))) > 0;
    }
}
