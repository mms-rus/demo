package com.example.demo.service;

import com.example.demo.dto.UserDto;
import com.example.demo.dto.UserFilterDto;
import com.example.demo.model.Account;
import com.example.demo.model.User;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface UserService {
    List<Account> findAccountList(Integer offset, Integer size);

    User getUserByEmail(String email);

    List<User> getUserListByFilter(String name, String email, String phone, Date dtOfBirth, Integer offset, Integer size);

    User getUserByPhone(String login);

    User findByUsername(String username);
}
