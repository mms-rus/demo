package com.example.demo.dao;

import com.example.demo.dto.UserFilterDto;
import com.example.demo.model.User;
import jakarta.persistence.criteria.CriteriaQuery;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
@EnableJpaRepositories
public interface UserRepositoryCustom {
    List<User> findUserListByFilter(Integer offset, Integer size, UserFilterDto filter);
}
